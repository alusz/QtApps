#include "mainwindow.h"
#include "ui_mainwindow.h"
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    img = new QImage(":/dog.jpg");
    img_prim = new QImage(":/dog.jpg");
    img2 = new QImage(ui->frame_2->width(),ui->frame_2->height(),QImage::Format_RGB32);
    draw();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event){

    x = event-> x() - ui->frame->x();
    y = event -> y() - ui->frame->y();


    if(x0==x && y0 == y){
            setPixel(x0,y0,255,0,0,img);
            pointsX[counter] = x0;
            pointsY[counter] = y0;
            counter ++;

            if(counter == 3 ){
                draw_triangle();
                xta = pointsX[0];
                yta = pointsY[0];
                xtb = pointsX[1];
                ytb = pointsY[1];
                xtc = pointsX[2];
                ytc = pointsY[2];
            }
    }
    else{
        if( x - 4 >= 0 && x + 4 <= img->width() && y - 4 >= 0 && y + 4 <= img->height()){
        for(int i = 0; i < counter; i++){
            if(abs(pointsX[i] - x0) <= 3 && abs(pointsY[i] - y0) <= 3){
               setPixel(x,y,255,0,0,img);

               pointsX[i] = x;
               pointsY[i] = y;


        uchar *ind;

            for(int i = x0-5; i <= x0+5; i++){
                for(int j = y0 - 5; j <= y0 + 5; j++){

               ind = img->scanLine(j);
               ind[4 * i] = static_cast<uchar>(img_prim->pixelColor(i,j).blue());
               ind[ 4 * i + 1] = static_cast<uchar>(img_prim->pixelColor(i,j).green());
               ind[ 4 * i + 2] = static_cast<uchar>(img_prim->pixelColor(i,j).red());

                 }
               }
             }
           }
         }
     }
    if(counter >= 3){
        barycentric(pointsX[0], pointsY[0],pointsX[1], pointsY[1],pointsX[2], pointsY[2]);
        uchar *ind;
        for(int i = 0; i < img->width(); i++){
            for(int j = 0; j < img -> height(); j++){
                    ind = img->scanLine(j);
                    ind[4 * i] = static_cast<uchar>(img_prim->pixelColor(i,j).blue());
                    ind[ 4 * i + 1] = static_cast<uchar>(img_prim->pixelColor(i,j).green());
                    ind[ 4 * i + 2] = static_cast<uchar>(img_prim->pixelColor(i,j).red());

            }
        }
        draw_section(pointsX[0], pointsY[0],pointsX[1], pointsY[1],255,0,0,img);
        draw_section(pointsX[0], pointsY[0],pointsX[2], pointsY[2],255,0,0,img);
        draw_section(pointsX[2], pointsY[2],pointsX[1], pointsY[1],255,0,0,img);

        setPixel(pointsX[0], pointsY[0],255,0,0,img);
        setPixel(pointsX[1], pointsY[1],255,0,0,img);
        setPixel(pointsX[2], pointsY[2],255,0,0,img);

    }
    update();
}


void MainWindow::mousePressEvent(QMouseEvent *event){

    x0 = event-> x() - ui->frame->x();
    y0 = event -> y() - ui->frame->y();

}

void MainWindow::on_exit_clicked()
{
       qApp -> quit();
}

double MainWindow::count_det(double x0, double x1, double y0, double y1){
    return x0 * y1 - y0 * x1;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter p(this), p2(this);

    p.drawImage(ui ->frame->x(), ui ->frame->y(), *img);
    p2.drawImage(ui->frame_2->x(), ui->frame_2->y(), *img2);

}

void MainWindow::draw_triangle(){

    for(int i = 0 ; i < 3; i++){
        setPixel(pointsX[i], pointsY[i], 0, 0, 0, img2);
    }
}

void MainWindow::draw(){
    uchar *ind;
    for(int i = 0; i < ui->frame_2->height(); i++)
    {
        ind = img2->scanLine(i);
        for(int j = 0 ; j < ui->frame_2->width(); j++)
        {
            ind[4*j] = 255; // BLUE
            ind[4*j + 1] = 255; // GREEN
            ind[4*j + 2] = 255; // RED

        }
    }
}

void MainWindow::setPixel(int x, int y, int r, int g , int b, QImage *image ){
   uchar *ind;
if(x >=0 && y >=0 && x <  ui->frame->width() && y <  ui->frame->height() ){
       for(int i = x-3; i < x+3; i++){
           for(int j = y - 3; j < y + 3; j++){

                   ind = image->scanLine(j);
                   ind[4 * i] = static_cast<uchar>(b);
                   ind[ 4 * i + 1] = static_cast<uchar>(g);
                   ind[ 4 * i + 2] = static_cast<uchar>(r);

           }
       }

}
    update();
}

void MainWindow::setCommonPixel(int x, int y, int r, int g , int b, QImage *image ){
   uchar *ind;
if(x >=0 && y >=0 && x <  ui->frame->width() && y <  ui->frame->height() ){

                   ind = image->scanLine(y);
                   ind[4 * x] = static_cast<uchar>(b);
                   ind[ 4 * x + 1] = static_cast<uchar>(g);
                   ind[ 4 * x + 2] = static_cast<uchar>(r);

}
    update();
}


void MainWindow::barycentric(int xa, int ya, int xb, int yb, int xc, int yc){
    double v, w, u;
    int min_x = MIN(xta,MIN(xtb,xtc));
    int max_x = MAX(xta, MAX(xtb,xtc));
    int min_y = MIN(yta,MIN(ytb,ytc));
    int max_y = MAX(yta, MAX(ytb,ytc));
    uchar *ind;

    for(int i = min_x ; i <= max_x; i++){
        for(int j = min_y ; j <= max_y ; j++){
            ind = img2->scanLine(j);
            v = calculate_v(i, xta, xtb, xtc, j, yta, ytb, ytc);
            w = calculate_w(i, xta, xtb, xtc, j, yta, ytb, ytc);
            u = 1 - v - w;
           if(u <= 1 && u >= 0 && v <= 1 && v >= 0 && w <= 1 && w >= 0){

               int x_floor = qFloor(u * xa + v * xb + w * xc);
               int x_ceil = qCeil(u * xa + v * xb + w * xc);
               int y_floor = qFloor(u * ya + v * yb + w * yc);
               int y_ceil = qCeil(u * ya + v * yb + w * yc);

               QColor color_1 = img_prim->pixelColor(x_floor, y_floor);
               QColor color_2 = img_prim->pixelColor(x_ceil, y_floor);
               QColor color_3 = img_prim->pixelColor(x_ceil, y_ceil);
               QColor color_4 = img_prim->pixelColor(x_floor, y_ceil);

               double a = fabs(u * xa + v * xb + w * xc - x_floor);
               double b = fabs(u * ya + v * yb + w * yc - y_ceil);

              setCommonPixel
                       (static_cast<int>(round(u * xta + v * xtb + w * xtc)),
                        static_cast<int>(round(u * yta + v * ytb + w * ytc)),
                       static_cast<int>(b*((1-a)*color_1.red() + a * color_2.red()) + (1-b)*((1-a)*color_4.red() + a * color_3.red())),
                       static_cast<int>(b*((1-a)*color_1.green() + a * color_2.green()) + (1-b)*((1-a)*color_4.green() + a * color_3.green())),
                       static_cast<int>(b*((1-a)*color_1.blue() + a * color_2.blue()) + (1-b)*((1-a)*color_4.blue() + a * color_3.blue())),
                        img2 );
           }

        }

    }


    draw_section(xta, yta, xtb, ytb, 0,0,0, img2);
    draw_section(xtb, ytb, xtc, ytc, 0,0,0, img2);
    draw_section(xta, yta, xtc, ytc, 0,0,0, img2);


    update();

}

double MainWindow::calculate_v(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc){
    double v = count_det(x - xa, xc - xa, y - ya, yc - ya) / count_det(xb - xa, xc - xa, yb - ya, yc - ya);
    return v;
}

double MainWindow::calculate_w(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc){
    double w = count_det(xb - xa, x - xa, yb - ya, y - ya) / count_det(xb - xa, xc - xa, yb - ya, yc - ya);
    return w;
}


void MainWindow::on_reset_clicked()
{
   *img = img_prim->copy();
    draw();
    counter = 0;
    update();
}

void MainWindow::draw_section(int x0, int y0, int x1, int y1, int r, int g, int b, QImage *img){

   if(x1 < x0){
      int temp = x0;
      x0 = x1;
      x1 = temp;
      int temp2 = y0;
      y0 = y1;
      y1 = temp2;
   }


   double dy = double(y1-y0);
   double dx = double(x1-x0);


if(dx==0.0){
    dx = 1;
}
    double  a = dy/dx;
   double  bb = y0 - a* x0;


  if(x0==x1){
       for(int y=y0; y <= y1; y++){
           int  x = int ((y-bb)/a);

               setCommonPixel(x, y, r, g, b,img);
       }
   }

if(fabs(dx) > fabs(dy)){
       for(int x = x0; x <= x1; x++){
        int  y = int (a * x + bb);

           setCommonPixel(x, y, r, g, b,img);

       }
}else{

    if(y1 < y0){
        int temp_y = y0;
        y0 = y1;
        y1 = temp_y;
        int temp_x = x0;
        x0 = x1;
        x1 = temp_x;
    }

    for(int y = y0; y <= y1; y++){
     int  x = int ((y-bb)/a);

        setCommonPixel(x, y, r, g, b,img);

    }

}
}
