#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QDebug>
#include <QMouseEvent>
#include <QVector>
#include <QtMath>
#include <QColor>
#include <QRgb>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void paintEvent(QPaintEvent *event);
    void on_exit_clicked();
    double count_det(double x0, double x1, double y0, double y1);
    void draw();
    void on_reset_clicked();
    void setPixel(int x, int y, int r, int g , int b, QImage *image );
    void setCommonPixel(int x, int y, int r, int g , int b, QImage *image );
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void draw_triangle();
    void barycentric(int xa, int ya, int xb, int yb, int xc, int yc);
    double calculate_v(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc);
    double calculate_w(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc);
    void draw_section(int x0, int y0, int x1, int y1, int r, int g, int b, QImage *img);

private:
    Ui::MainWindow *ui;
    QImage *img, *img2, *img_prim;
    int x, y, x0, y0;
    QVector<int> vector_x;
     QVector<int> vector_y;
    int pointsX[1000];
    int pointsY[1000];
    int counter = 0;
    int xta, yta, xtb, ytb, xtc, ytc;
};

#endif // MAINWINDOW_H
