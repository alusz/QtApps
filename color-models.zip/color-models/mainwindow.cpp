#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    width = ui->frame-> width();
    height = ui->frame->height();
    startX = ui ->frame->x();
    startY = ui ->frame->y();
    count_H(red,green,blue);
    img = new QImage(width,height,QImage::Format_RGB32);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter p(this);

    p.drawImage(startX, startY, *img);
}


void MainWindow::on_horizontalSlider_sliderMoved(int position)
{
    red = position * 255 / 99;
    ui -> label_7 ->setText("Green -> ");
    ui -> label_8 ->setText("B\nl\nu\ne\n \n|\nv");
    ui -> label_9 ->setText("255");
    ui -> label_10 ->setText("255");

    ui -> spinBox -> setValue(red);

    uchar *ind;
    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            ind[4*j] = static_cast<uchar>(i * 255/ height); // BLUE
            ind[4*j + 1] = static_cast<uchar>(j * 255/width); // GREEN
            ind[4*j + 2] = static_cast<uchar>(red); // RED

          count_H(red,green,blue);
        }
    }
        ui -> spinBox_4 -> setValue(static_cast<int>(H));
        ui -> horizontalSlider_4 -> setValue(static_cast<int>(H/ 3.6));
        ui -> spinBox_5 -> setValue(static_cast<int>(S*100));
        ui -> horizontalSlider_5 -> setValue(static_cast<int>(S*100));
        ui -> spinBox_6 -> setValue(static_cast<int>(V/2.55));
        ui -> horizontalSlider_6 -> setValue(static_cast<int>(V/2.55));
        update();

}

void MainWindow::on_horizontalSlider_2_sliderMoved(int position)
{
    green = position * 255 / 99;
    ui -> label_7 ->setText("Red -> ");
    ui -> label_8 ->setText("B\nl\nu\ne\n \n|\nv");
    ui -> label_9 ->setText("255");
    ui -> label_10 ->setText("255");

    ui -> spinBox_2 -> setValue(green);

    uchar *ind;
    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            ind[4*j] = static_cast<uchar>(i * 255/ height); // BLUE
            ind[4*j + 1] = static_cast<uchar>(green); // GREEN
            ind[4*j + 2] = static_cast<uchar>(j * 255/width) ;// RED
           count_H(red, green, blue);
         }
     }
        ui -> spinBox_4 -> setValue(static_cast<int>(H));
        ui -> horizontalSlider_4 -> setValue(static_cast<int>(H/ 3.6));
        ui -> spinBox_5 -> setValue(static_cast<int>(S*100));
        ui -> horizontalSlider_5 -> setValue(static_cast<int>(S*100));
        ui -> spinBox_6 -> setValue(static_cast<int>(V/2.55));
        ui -> horizontalSlider_6 ->setValue(static_cast<int>(V/2.55));


    update();

}

void MainWindow::on_horizontalSlider_3_sliderMoved(int position)
{
    blue = position * 255/99;
    ui -> label_7 ->setText("Red -> ");
    ui -> label_8 ->setText("G\nr\ne\ne\nn\n \n|\nv ");
    ui -> label_9 ->setText("255");
    ui -> label_10 ->setText("255");

    ui -> spinBox_3 -> setValue(blue);


    uchar *ind;
    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            ind[4*j] = static_cast<uchar>(blue); // BLUE
            ind[4*j + 1] = static_cast<uchar>(i * 255 / height); // GREEN
            ind[4*j + 2] = static_cast<uchar>(j * 255/width) ;// RED

         count_H(red, green, blue);
         }
     }
        ui -> spinBox_4 -> setValue(static_cast<int>(H));
        ui -> horizontalSlider_4 -> setValue(static_cast<int>(H/3.6));
        ui -> spinBox_5 -> setValue(static_cast<int>(S*100));
        ui -> horizontalSlider_5 -> setValue(static_cast<int>(S*100));
        ui -> spinBox_6 -> setValue(static_cast<int>(V/2.55));
        ui -> horizontalSlider_6 -> setValue(static_cast<int>(V/2.55));

    update();
}


double MainWindow::count_f(double H, double S, double V, int n){

    double sum = n+(H/60);
    int divider = static_cast<int>(sum) / 6;
    double k = sum - divider * 6;
    double min = k;

    if(4 - k < min){
        min = 4 - k;
    }
    if(1 < min){
        min = 1;
    }

    double max = min;

    if(0 > max){
        max = 0;
    }

    return (V-V*S*max)*255;
}

double MainWindow::count_H(double R, double G, double B){

    double max = R;
    if(G - max > 0.0){
        max = G;
    }
    if(B - max> 0.0){
        max = B;
    }
    V = max;

    double min = R;
    if(G < min){
        min = G;
    }
    if(B < min){
        min = B;
    }

    double C = max - min;
    S = C / max;

    if( C == 0.0){
        H = 0;
    }else{
        if(max - R == 0.0){
            H = (G-B)*60/C;
        }
        if(max - G == 0.0){
            H = 120 + ((B-R)*60/C);
        }
        if(max - B == 0.0){
            H = 240 + ((R-G)*60/C);
        }
    }

    if(H < 0){
        H += 360;
    }
    return H;
}


void MainWindow::on_horizontalSlider_4_sliderMoved(int position)
{
    H = position * 360/99;
    ui -> label_7 ->setText("Saturation -> ");
    ui -> label_8 ->setText("V\na\nl\nu\ne\n \n|\nv ");
    ui -> label_9 ->setText("100");
    ui -> label_10 ->setText("100");
    ui -> spinBox_4 -> setValue(static_cast<int>(H));
    uchar *ind;
    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            ind[4*j] = static_cast<uchar>(count_f(position * 3.6, j * 0.001996008,i * 0.002079002, 1)); // BLUE
            ind[4*j + 1] = static_cast<uchar>(count_f(position * 3.6, j * 0.001996008,i * 0.002079002, 3)); // GREEN
            ind[4*j + 2] = static_cast<uchar>(count_f(position * 3.6, j * 0.001996008,i * 0.002079002, 5));// RED

        }
    }

    update();

}

void MainWindow::on_horizontalSlider_5_sliderMoved(int position)
{
    S = position;
    ui -> label_7 ->setText("Hue -> ");
    ui -> label_8 ->setText("V\na\nl\nu\ne\n \n|\nv  ");
    ui -> label_9 ->setText("360");
    ui -> label_10 ->setText("100");
    ui -> spinBox_5 -> setValue(static_cast<int>(S));

    uchar *ind;
    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            ind[4*j] = static_cast<uchar>(count_f( j * 0.71656687, position * 0.01 ,i * 0.002079002 , 1)); // BLUE
            ind[4*j + 1] = static_cast<uchar>(count_f( j * 0.71656687, position *  0.01,  i * 0.002079002,  3)); // GREEN
            ind[4*j + 2] = static_cast<uchar>(count_f( j * 0.71656687, position * 0.01, i*0.002, 5));// RED
        }
    }
    update();
}

void MainWindow::on_horizontalSlider_6_sliderMoved(int position)
{
    V = position;
    ui -> label_7 ->setText("Hue -> ");
    ui -> label_8 ->setText("S\na\nt\nu\nr\na\nt\ni\no\nn\n|\nv ");
    ui -> label_9 ->setText("360");
    ui -> label_10 ->setText("100");
    ui -> spinBox_6 -> setValue(static_cast<int>(V));

    uchar *ind;
    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            ind[4*j] = static_cast<uchar>(count_f(j* 0.71656687, i * 0.002079002 , position * 0.01 , 1)); // BLUE
            ind[4*j + 1] = static_cast<uchar>(count_f(j* 0.71656687 , i * 0.002079002, position * 0.01, 3)); // GREEN
            ind[4*j + 2] = static_cast<uchar>(count_f(j* 0.71656687 , i * 0.002079002, position * 0.01, 5));// RED
        }
    }

    update();
}

void MainWindow::on_pushButton_clicked()
{
   qApp -> quit();
}
