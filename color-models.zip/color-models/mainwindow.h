#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#include <QMainWindow>
#include <QWidget>
#include <QLabel>
#include <QPainter>
#include <QtMath>
#include <QDebug>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
     void paintEvent(QPaintEvent *event);
    void on_horizontalSlider_sliderMoved(int position);

    void on_horizontalSlider_2_sliderMoved(int position);

    void on_horizontalSlider_3_sliderMoved(int position);

    void on_horizontalSlider_4_sliderMoved(int position);

    void on_horizontalSlider_5_sliderMoved(int position);

    void on_horizontalSlider_6_sliderMoved(int position);

    double count_f(double H, double S, double V, int n);

    double count_H(double R, double G, double B);



    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QImage *img;
    int width, height, startX, startY, red=0, green=0, blue=0;
    double H, S,min, V, R, G, B;

};

#endif // MAINWINDOW_H
