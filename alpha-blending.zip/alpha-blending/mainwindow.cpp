#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    width = ui->frame-> width();
    height = ui->frame->height();
    startX = ui ->frame->x();
    startY = ui ->frame->y();

    img0= new QImage(":/happy-cat.jpg");
    img00= new QImage(":/happy-cat.jpg");
    img = new QImage(":/cat.jpeg");
    img2 = new QImage(":/dog.jpg");
    img3 = new QImage(":/flower.jpg");
    img4 = new QImage(":/fox.jpg");
    result = new QImage();
    *result = img00 -> copy();
    p1 = new QImage(864, 575, QImage::Format_ARGB32);


    ui->comboBox->addItem("Multiply mode");
    ui->comboBox->addItem("Normal mode");
    ui->comboBox->addItem("Screen mode");
    ui->comboBox->addItem("Subtractive mode");
    ui->comboBox->addItem("Additive mode");
    ui->comboBox->addItem("Difference mode");
    ui->comboBox->addItem("Negation mode");


    ui->comboBox_2->addItem("Multiply mode");
    ui->comboBox_2->addItem("Normal mode");
    ui->comboBox_2->addItem("Screen mode");
    ui->comboBox_2->addItem("Subtractive mode");
    ui->comboBox_2->addItem("Additive mode");
    ui->comboBox_2->addItem("Difference mode");
    ui->comboBox_2->addItem("Negation mode");

    ui->comboBox_3->addItem("Multiply mode");
    ui->comboBox_3->addItem("Normal mode");
    ui->comboBox_3->addItem("Screen mode");
    ui->comboBox_3->addItem("Subtractive mode");
    ui->comboBox_3->addItem("Additive mode");
    ui->comboBox_3->addItem("Difference mode");
    ui->comboBox_3->addItem("Negation mode");

    ui->comboBox_4->addItem("Multiply mode");
    ui->comboBox_4->addItem("Normal mode");
    ui->comboBox_4->addItem("Screen mode");
    ui->comboBox_4->addItem("Subtractive mode");
    ui->comboBox_4->addItem("Additive mode");
    ui->comboBox_4->addItem("Difference mode");
    ui->comboBox_4->addItem("Negation mode");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter p(this);

p.drawImage(startX, startY, *img0);

}
void MainWindow::on_pushButton_clicked()
{
    qApp -> quit();
}


void MainWindow::on_horizontalSlider_sliderMoved(int position)
{

   alpha = position/100.0;

   actual();

   choice = ui -> comboBox -> currentText();
   update();
   actual();

}


void MainWindow::on_horizontalSlider_2_sliderMoved(int position)
{
   alpha2 = position/100.0;

   actual();

   choice2 = ui -> comboBox_2 -> currentText();
   update();
   actual();

}

QImage MainWindow::choice_the_type(QString choice, QImage p0, QImage p2){
    if(choice == "Normal mode"){
            *p1 = normal_mode(p0,p2);
            update();
        }
        if(choice == "Multiply mode"){
            *p1 = multiply_mode(p0,p2);
            update();
        }
        if(choice == "Screen mode"){
            *p1 = screen_mode(p0,p2);
            update();
        }
        if(choice == "Subtractive mode"){
            *p1 = subtractive_mode(p0,p2);
            update();
        }
        if(choice == "Additive mode"){
            *p1 = additive_mode(p0,p2);
            update();
        }
        if(choice == "Difference mode"){
            *p1 = difference_mode(p0,p2);
            update();
        }
        if(choice == "Negation mode"){
            *p1 = negation_mode(p0,p2);
            update();
        }

     return *p1;
}

void MainWindow::on_horizontalSlider_3_sliderMoved(int position)
{
    alpha3 = position/100.0;

    actual();

    choice3 = ui -> comboBox_3 -> currentText();
    update();
    actual();
}

void MainWindow::on_horizontalSlider_4_sliderMoved(int position)
{
    alpha4 = position/100.0;

    actual();

    choice4 = ui -> comboBox_4 -> currentText();
    update();
    actual();
}


QImage MainWindow::mix(QImage p0,QImage p2, double alpha, QString choice){

    uchar *ind2, *ind1, *ind0;
    p0=choice_the_type(choice,p0,p2);
    update();


    for(int i = 0; i < img0->height(); i++)
    {
        ind0 = result->scanLine(i);
        ind2 = p2.scanLine(i);
        ind1 = p0.scanLine(i);

        for(int j=0; j < img0 -> width(); j++)
        {
           ind0[4*j] = static_cast<uchar>(ind1[4*j] * alpha + ind2[4*j] * (1 - alpha)) ;// BLUE
           ind0[4*j + 1] = static_cast<uchar>(ind1[4*j + 1] * alpha +  ind2[4*j + 1 ] * (1 - alpha)) ; // GREEN
            ind0[4*j + 2] = static_cast<uchar>(ind1[4*j + 2] * alpha +  ind2[4*j + 2] * (1 - alpha));// RED

        }
 }

*img0=result->copy();
update();
 return *result;
}

void MainWindow::actual(){

     *result = img00->copy();
    update();

    if(ui -> checkBox_Dog->isChecked()){
        mix(*img2, *result, alpha, choice);
        update();
    }
    if(ui -> checkBox_Cat->isChecked()){
        mix(*img, *result, alpha2, choice2);
        update();
    }
    if(ui -> checkBox_Flowers->isChecked()){
        mix(*img3, *result, alpha3, choice3);
        update();
    }
    if(ui -> checkBox_Fox->isChecked()){
        mix(*img4, *result, alpha4, choice4);
        update();
    }

  if(!(ui -> checkBox_Dog->isChecked()) && !(ui -> checkBox_Cat->isChecked()) && !(ui -> checkBox_Flowers->isChecked()) && !(ui -> checkBox_Fox->isChecked())){
      *img0 = img00->copy();
        update();
   }
}

QImage MainWindow::normal_mode(QImage p1, QImage p2){
    return p1;
}

QImage MainWindow::multiply_mode(QImage p0, QImage p2){
    uchar *ind2, *ind1, *ind0;
    for(int i = 0; i < img0->height(); i++)
    {
        ind0 = p1->scanLine(i);
        ind2 = p2.scanLine(i);
        ind1 = p0.scanLine(i);

        for(int j=0; j < img0 -> width(); j++)
        {
           ind0[4*j] = ind1[4*j] *  ind2[4*j] >> 8 ;// BLUE
           ind0[4*j + 1] = ind1[4*j + 1] * ind2[4*j + 1 ] >> 8 ; // GREEN
           ind0[4*j + 2] = ind1[4*j + 2] *  ind2[4*j + 2] >> 8;// RED
        }
 }
 return *p1;
}

QImage MainWindow::screen_mode(QImage p0, QImage p2){
    uchar *ind2, *ind1, *ind0;
    for(int i = 0; i < img0->height(); i++)
    {
        ind0 = p1->scanLine(i);
        ind2 = p2.scanLine(i);
        ind1 = p0.scanLine(i);

        for(int j=0; j < img0 -> width(); j++)
        {
           ind0[4*j] = 255 - ((255 - ind1[4*j]) *  (255 - ind2[4*j]) >> 8) ;// BLUE
           ind0[4*j + 1] = 255 - ((255 - ind1[4*j + 1]) *  (255 - ind2[4*j] + 1) >> 8) ; // GREEN
           ind0[4*j + 2] = 255 - ((255 - ind1[4*j + 2]) *  (255 - ind2[4*j] + 2) >> 8);// RED

        }
 }
 return *p1;
}

QImage MainWindow::difference_mode(QImage p0, QImage p2){
    uchar *ind2, *ind1, *ind0;
    for(int i = 0; i < img0->height(); i++)
    {
        ind0 = p1->scanLine(i);
        ind2 = p2.scanLine(i);
        ind1 = p0.scanLine(i);

        for(int j=0; j < img0 -> width(); j++)
        {
            ind0[4*j] = static_cast<uchar>(abs(ind1[4*j] - ind2[4*j])) ;// BLUE
            ind0[4*j + 1] = static_cast<uchar>(abs(ind1[4*j + 1] - ind2[4*j + 2] )) ; // GREEN
            ind0[4*j + 2] = static_cast<uchar>(abs(ind1[4*j + 2] - ind2[4*j + 2]));// RED

        }
 }
 return *p1;
}

QImage MainWindow::negation_mode(QImage p0, QImage p2){
    uchar *ind2, *ind1, *ind0;
    for(int i = 0; i < img0->height(); i++)
    {
        ind0 = p1->scanLine(i);
        ind2 = p2.scanLine(i);
        ind1 = p0.scanLine(i);

        for(int j=0; j < img0 -> width(); j++)
        {
            ind0[4*j] = static_cast<uchar>(255 - abs(255 - ind1[4*j] - ind2[4*j])) ;// BLUE
            ind0[4*j + 1] = static_cast<uchar>(255 - abs(255 - ind1[4*j + 1] - ind2[4*j + 2] )) ; // GREEN
            ind0[4*j + 2] = static_cast<uchar>(255  - abs(255 - ind1[4*j + 2] - ind2[4*j + 2]));// RED

        }
 }
 return *p1;
}

QImage MainWindow::additive_mode(QImage p0, QImage p2){
    uchar *ind2, *ind1, *ind0;
    for(int i = 0; i < img0->height(); i++)
    {
        ind0 = p1->scanLine(i);
        ind2 = p2.scanLine(i);
        ind1 = p0.scanLine(i);

        for(int j=0; j < img0 -> width(); j++)
        {
            if(ind1[4*j]+ind2[4*j] < 255){
                ind0[4*j] = ind1[4*j]+ind2[4*j];
            }else{
                 ind0[4*j] = 255;
            }
            if(ind1[4*j+1]+ind2[4*j+1] < 255){
                ind0[4*j+1] = ind1[4*j+1]+ind2[4*j+1];
            }else{
                 ind0[4*j+1] = 255;
            }
            if(ind1[4*j+2]+ind2[4*j+2] < 255){
                ind0[4*j+2] = ind1[4*j+2]+ind2[4*j+2];
            }else{
                 ind0[4*j+2] = 255;
            }
        }
 }
 return *p1;
}

QImage MainWindow::subtractive_mode(QImage p0, QImage p2){
    uchar *ind2, *ind1, *ind0;
    for(int i = 0; i < img0->height(); i++)
    {
        ind0 = p1->scanLine(i);
        ind2 = p2.scanLine(i);
        ind1 = p0.scanLine(i);

        for(int j=0; j < img0 -> width(); j++)
        {
            if(ind1[4*j]+ind2[4*j] > 255){
                ind0[4*j] = ind1[4*j]+ind2[4*j] - 255;
            }else{
                 ind0[4*j] = 0;
            }
            if(ind1[4*j+1]+ind2[4*j+1] > 255){
                ind0[4*j+1] = ind1[4*j+1]+ind2[4*j+1] - 255;
            }else{
                 ind0[4*j+1] = 0;
            }
            if(ind1[4*j+2]+ind2[4*j+2] > 255){
                ind0[4*j+2] = ind1[4*j+2]+ind2[4*j+2] - 255;
            }else{
                 ind0[4*j+2] = 0;
            }

        }

 }
 return *p1;
}


void MainWindow::on_checkBox_Dog_toggled()
{
    actual();
}
void MainWindow::on_checkBox_Cat_toggled()
{
    actual();
}

void MainWindow::on_checkBox_Flowers_toggled()
{
    actual();
}

void MainWindow::on_checkBox_Fox_toggled()
{
    actual();
}

void MainWindow::on_comboBox_currentTextChanged()
{
    choice = ui -> comboBox -> currentText();
    update();
    actual();
}

void MainWindow::on_comboBox_2_currentTextChanged()
{
    choice2 = ui -> comboBox_2 -> currentText();
    update();
    actual();
}

void MainWindow::on_comboBox_3_currentTextChanged()
{
    choice3 = ui -> comboBox_3 -> currentText();
    update();
    actual();
}

void MainWindow::on_comboBox_4_currentTextChanged()
{
    choice4 = ui -> comboBox_4 -> currentText();
    update();
    actual();
}
