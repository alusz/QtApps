#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QMouseEvent>
#include <QColor>
#include <cmath>
#include <QDebug>
#include <QtMath>
#include <QMessageBox>
#include <QtWidgets>
#include <QTabWidget>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    void paintEvent(QPaintEvent *event);

    void on_horizontalSlider_sliderMoved(int position);

    void on_horizontalSlider_2_sliderMoved(int position);

    QImage mix(QImage p1,QImage p2, double alpha, QString choice);

    void actual();

    QImage normal_mode(QImage p1, QImage p2);

    QImage multiply_mode(QImage p1, QImage p2);

    QImage screen_mode(QImage p1, QImage p2);
    QImage subtractive_mode(QImage p1, QImage p2);
    QImage additive_mode(QImage p1, QImage p2);
    QImage difference_mode(QImage p1, QImage p2);
    QImage negation_mode(QImage p1, QImage p2);

    void on_checkBox_Dog_toggled();

    void on_checkBox_Cat_toggled();

    void on_checkBox_Flowers_toggled();

    void on_checkBox_Fox_toggled();

    void on_horizontalSlider_3_sliderMoved(int position);

    void on_horizontalSlider_4_sliderMoved(int position);

    QImage choice_the_type(QString choice, QImage p1, QImage p2);

    void on_comboBox_currentTextChanged();

    void on_comboBox_2_currentTextChanged();

    void on_comboBox_3_currentTextChanged();

    void on_comboBox_4_currentTextChanged();

private:
    Ui::MainWindow *ui;
    QImage *img, *img2, *img3, *img0, *img4, *img00, *result, *p1;
    int width, height;
    int startX, startY;

    QString choice, choice2, choice3, choice4;

    double alpha = 0, alpha2 = 0, alpha3 = 0, alpha4 = 0;

};


#endif // MAINWINDOW_H

