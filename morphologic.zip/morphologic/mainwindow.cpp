#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    width = ui->frame-> width();
    height = ui->frame->height();
    startX = ui ->frame->x();
    startY = ui ->frame->y();


   img = new QImage(":/image.jpg");
   dark(img);
  // draw();
   update();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter p(this);

    p.drawImage(startX, startY, *img);

}

void MainWindow::on_pushButton_clicked()
{
    if(frames == 0){
         QMessageBox::warning(this, "Execution error.", "Frame number is too small. Give at least 1");
    }else{
erosion();}

}

void MainWindow::on_pushButton_2_clicked()
{
    if(frames == 0){
         QMessageBox::warning(this, "Execution error.", "Frame number is too small. Give at least 1");
    }else{
dilation();}
}

void MainWindow::on_pushButton_3_clicked()
{
    if(frames == 0){
         QMessageBox::warning(this, "Execution error.", "Frame number is too small. Give at least 1");
    }else{
opening();}
}


void MainWindow::on_pushButton_4_clicked()
{
    if(frames == 0){
         QMessageBox::warning(this, "Execution error.", "Frame number is too small. Give at least 1");
    }else{
closing();}
}


void MainWindow::on_pushButton_5_clicked()
{
        filename = QFileDialog::getOpenFileName(this, tr("Open image"), "/home",tr("Image Files (*.png *.jpg *.jpeg *.bmp)"));
        img0 = new QImage(filename);
        dark(img0);
        *img = img0->copy(0,0, width, height);
          update();
          delete img0;
}

void MainWindow::on_pushButton_6_clicked()
{
    draw();
    update();
}

void MainWindow::on_pushButton_7_clicked()
{
    qApp -> quit();
}

void MainWindow::dark(QImage *img){
    uchar *ind;
    int x;

    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            x = ind[4*j] + ind[4*j + 1] + ind[4*j+ 2 ];

            if(x > 170){

            ind[4*j] = 255;
            ind[4*j+1] = 255;
            ind[4*j+2] = 255;

            }
            else{

                ind[4*j] = 0;
                ind[4*j+1] = 0;
                ind[4*j+2] = 0;}
            }
        }
    }

void MainWindow::opening(){

erosion();
dilation();

}

void MainWindow::closing(){
   dilation();
   erosion();

}

void MainWindow::dilation()
{
    uchar *ind;
    QImage tmp(*img);


    for(int i = 0; i<height; i++)
    {
        ind = tmp.scanLine(i);
        for(int j = 0; j<width; j++)
        {
            if(checking(j, i, frames, 0))
            {
                ind[4*j]   = 0;
                ind[4*j + 1] = 0;
                ind[4*j + 2] = 0;
            }
        }
    }
    *img = tmp.copy();
    update();
    }

void MainWindow::erosion()
{

    uchar *ind;
    QImage tmp(*img);

    for(int i = 0; i<height; i++)
    {
        ind = tmp.scanLine(i);
        for(int j = 0; j<width; j++)
        {
            if(checking(j, i, frames, 255))
            {
                ind[4*j]   = 255;
                ind[4*j + 1] = 255;
                ind[4*j + 2] = 255;
            }
        }
    }
    *img = tmp.copy();
    update();
    }



bool MainWindow::checking(int x, int y, int k, int colorNb)
{


    int x0 = x - k;
    int x1 = x + k;
    int y0 = y - k;
    int y1 = y + k;

    if(x0 < 0){
        x0 = 0;
    }
    if(y0 < 0){
        y0 = 0;
    }
    if(x0 > width){
        x0 = width;
    }
    if(y0 > height){
        y0 = height;
    }

    if(x1 < 0){
        x1 = 0;
    }
    if(y1 < 0){
        y1 = 0;
    }
    if(x1 > width){
        x1 = width;
    }
    if(y1 > height){
        y1 = height;
    }


    uchar *ind;


    for(int i = y0; i <= y1; i++)
    {
        ind = img->scanLine(i);
        for(int j = x0; j <= x1; j++)
        {
            if(j==x && i==y) {
                continue;
            }

            if(ind[4*j]  == colorNb && ind[4*j + 1]== colorNb && ind[4*j + 2]== colorNb)
                return true;

        }
    }
    return false;
}


void MainWindow::draw(){
    uchar *ind;

    for(int i = 0; i < height; i++)
    {
        ind = img->scanLine(i);
        for(int j=0; j < width; j++)
        {
            ind[4*j] = 255; // BLUE
            ind[4*j + 1] = 255; // GREEN
            ind[4*j + 2] = 255; // RED

        }
    }
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    frames = arg1;
}
