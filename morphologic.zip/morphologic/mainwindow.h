#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QFileDialog>
#include <QMouseEvent>
#include <QMessageBox>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void draw();

    void dark(QImage *img);

    void dilation();

    void erosion();

    void opening();
    void closing();

    bool checking(int x, int y, int i, int kolor);

   void paintEvent(QPaintEvent *event);

   void on_spinBox_valueChanged(int arg1);

private:
    Ui::MainWindow *ui;
    int width, height, startX, startY, frames = 0, colorNb = 0;
    QImage *img, *img0;
    QString filename;
    QRgb color;
};

#endif // MAINWINDOW_H
