#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QDebug>
#include <QMouseEvent>
#include <QtMath>
#include <QColor>
#include <QRgb>
#include <QTimer>
#include <QMessageBox>
#include <QVector>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void paintEvent(QPaintEvent *event);
    void timerEvent(QTimerEvent *event);
    void on_exit_clicked();
    double count_det(double x0, double x1, double y0, double y1);
    void draw(QImage *img2);
    void on_reset_clicked();
    void setPixel(int x, int y, int r, int g , int b, QImage *image );
    void setCommonPixel(int x, int y, int r, int g , int b, QImage *image );
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    QImage barycentric(int xta, int yta, int xtb, int ytb, int xtc, int ytc,int xa, int ya, int xb, int yb, int xc, int yc, QImage *img_prim, QImage *img);
    double calculate_v(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc);
    double calculate_w(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc);
    void draw_section(int x0, int y0, int x1, int y1, int r, int g, int b, QImage *img);
    void clean(int X[1000], int Y[1000], QImage *img, QImage *img2, int counter);
    void isCklicked(int x1, int x2, int y1, int y2, int X[1000], int Y[1000],QImage *img, QImage *img2, int counter);
    void start();
    void next();
    void reset();
    void display();
    void result();
    void on_framesNb_valueChanged(int arg1);
    void on_radioButton_toggled();
    void on_triangle_clicked();
    void on_radioButton_2_toggled();

private:
    Ui::MainWindow *ui;
    QImage *img, *img2, *img_prim, *angelina, *brad, *img2_prim, *result_1, *result_2, *temp;
    QTimer timer, timer2;
    int x, y, x0, y0, x1, x2, y1, y2;

    int pointsX[1000]={0,388,218,388,209,388,200,388,195,388,195,388,197,388,197,388,197,388,200,388,0,191,0,197,0,198,0,195,0,197,0,207,0,215,0,218};
    int pointsY[1000]={0,0,26,57,76,124,116,156,142,204,191,240,229,266,258,283,285,319,320,340,340,284,270,286,233,229,184,181,137,134,89,88,41,49,0,26};
    int pointsX2[1000]={0,388,212,388,207,388,205,388,206,388,209,388,211,388,210,388,207,388,215,388,0,212,0,207,0,212,0,210,0,205,0,206,0,212,0,212};
    int pointsY2[1000]={0,0,75,75,109,157,149,201,170,223,194,250,247,286,273,318,309,333,328,340,340,316,299,309,258,251,194,194,160,159,115,119,60,75,0,75};

    int pointsXtemp[1000]={0,388,218,388,209,388,200,388,195,388,195,388,197,388,197,388,197,388,200,388,0,191,0,197,0,198,0,195,0,197,0,207,0,215,0,218};
    int pointsYtemp[1000]={0,0,26,57,76,124,116,156,142,204,191,240,229,266,258,283,285,319,320,340,340,284,270,286,233,229,184,181,137,134,89,88,41,49,0,26};
    int pointsX2temp[1000]={0,388,212,388,207,388,205,388,206,388,209,388,211,388,210,388,207,388,215,388,0,212,0,207,0,212,0,210,0,205,0,206,0,212,0,212};
    int pointsY2temp[1000]={0,0,75,75,109,157,149,201,170,223,194,250,247,286,273,318,309,333,328,340,340,316,299,309,258,251,194,194,160,159,115,119,60,75,0,75};

    int counter = 36, counter2 = 36, clicked = 0, clicked2 = 0, n2 = 0;

    QVector <QImage> pictures;

    int xta, yta, xtb, ytb, xtc, ytc;
    int xta2=0, yta2=0, xtb2=0, ytb2=0, xtc2=0, ytc2=0;
    int xa, xb, xc, ya, yb, yc, n=0, frameNb = 60;
};

#endif // MAINWINDOW_H
