#include "mainwindow.h"
#include "ui_mainwindow.h"
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    angelina = new QImage(":/angeluina.jpg");
    brad = new QImage(":/Brad-Pitt-1024x803.jpg");

    img_prim = new QImage(":/angeluina.jpg");
    img2_prim = new QImage(":/brad3.jpg");

    clean(pointsX2, pointsY2, brad, img2_prim, counter2);
    clean(pointsX, pointsY, angelina, img_prim, counter);

    temp = new QImage(ui->result->width(),ui->result->height(),QImage::Format_RGB32);
    img2 = new QImage(ui->result->width(),ui->result->height(),QImage::Format_RGB32);
    result_1 = new QImage(ui->result->width(),ui->result->height(),QImage::Format_RGB32);
    result_2 = new QImage(ui->result->width(),ui->result->height(),QImage::Format_RGB32);
    ui->horizontalSlider->setVisible(false);

    connect(&timer, &QTimer::timeout, this, &MainWindow::next);
    connect(&timer2, &QTimer::timeout, this, &MainWindow::result);
    connect(ui->horizontalSlider,SIGNAL(valueChanged(int)), ui->progressBar, SLOT(setValue(int)));
    draw(img2);
}

void MainWindow::reset(){

    *angelina= img_prim->copy();
    *brad= img2_prim->copy();
    *result_1 = img2->copy();
    *result_2 = img2->copy();
    n = 0;
    n2 = 0;
    ui->horizontalSlider->setValue(0);
    update();
    draw(img2);
    if(counter > 3){
        clean(pointsX2, pointsY2, brad, img2_prim, counter2);
        clean(pointsX, pointsY, angelina, img_prim, counter);
    }

}

void MainWindow::on_radioButton_toggled()
{
    clicked ++;
    if(clicked % 2 == 1){
        counter = 0;
        counter2 = 0;
        reset();
    }
}

void MainWindow::on_radioButton_2_toggled()
{
    clicked2 ++;
    if(clicked2 %2 ==1){

     counter = 36;
     counter2 = 36;
       reset();

    for(int i= 0; i < 36; i++){
        pointsX[i] = pointsXtemp[i];
        pointsY[i] = pointsYtemp[i];
        pointsX2[i] = pointsX2temp[i];
        pointsY2[i] = pointsY2temp[i];
    }

    clean(pointsX2, pointsY2, brad, img2_prim, counter2);
    clean(pointsX, pointsY, angelina, img_prim, counter);
    }
}


MainWindow::~MainWindow()
{
    delete angelina;
    delete brad;
    delete img_prim;
    delete img2_prim;
    delete img2;
    delete result_1;
    delete result_2;
    delete ui;

}

void MainWindow::timerEvent(QTimerEvent *event)
{

}


void MainWindow::next()
{
   if(counter==3){ draw(temp);}
 ui->label_2->setText("Please wait...");
    for(int i = counter; i > 2 ; i--){

         xa = static_cast<int>((1.0- (static_cast<double>(n)/frameNb))* pointsX[i-3] + static_cast<double>(n)/frameNb * pointsX2[i-3]);
         xb = static_cast<int>((1.0- (static_cast<double>(n)/frameNb))* pointsX[i-2]+ static_cast<double>(n)/frameNb * pointsX2[i-2]);
         xc = static_cast<int>((1.0- (static_cast<double>(n)/frameNb))* pointsX[i-1] + static_cast<double>(n)/frameNb * pointsX2[i-1]);

         ya = static_cast<int>((1.0- (static_cast<double>(n)/frameNb))* pointsY[i-3] + static_cast<double>(n)/frameNb * pointsY2[i-3]);
         yb = static_cast<int>((1.0- (static_cast<double>(n)/frameNb))* pointsY[i-2]+ static_cast<double>(n)/frameNb * pointsY2[i-2]);
         yc = static_cast<int>((1.0- (static_cast<double>(n)/frameNb))* pointsY[i-1]+ static_cast<double>(n)/frameNb * pointsY2[i-1]);

         *result_1 = barycentric(xa,  ya,  xb, yb, xc, yc, xa, ya,  xb,  yb,  xc, yc, img_prim, result_1);
         *result_2 = barycentric(xa,  ya,  xb, yb, xc, yc, xa, ya,  xb,  yb,  xc, yc, img2_prim, result_2);

         uchar *wsk;

             for(int i = MIN(xc,MIN(xa,xb)); i <= MAX(xc,MAX(xa,xb)); i++){
                 for(int j = MIN(yc,MIN(ya,yb)); j <= MAX(yc,MAX(ya,yb)); j++){

                wsk = temp->scanLine(j);

               double v = calculate_v(i, xa, xb, xc, j, ya, yb, yc);
               double w = calculate_w(i, xa, xb, xc, j, ya, yb, yc);
               double u = 1 - v - w;
               if(u <= 1 && u >= 0 && v <= 1 && v >= 0 && w <= 1 && w >= 0){
                wsk[4 * i] = static_cast<uchar>((1.0 - static_cast<double>(n)/frameNb)*result_1->pixelColor(i,j).blue()+static_cast<double>(n)/frameNb*result_2->pixelColor(i,j).blue());
                wsk[ 4 * i + 1] = static_cast<uchar>((1.0 - static_cast<double>(n)/frameNb)*result_1->pixelColor(i,j).green()+static_cast<double>(n)/frameNb*result_2->pixelColor(i,j).green());
                wsk[ 4 * i + 2] = static_cast<uchar>((1.0 - static_cast<double>(n)/frameNb)*result_1->pixelColor(i,j).red()+static_cast<double>(n)/frameNb*result_2->pixelColor(i,j).red());

                    }
                 }
              }
    }
    pictures.insert(n, *temp);
    n++;
    ui->horizontalSlider->setValue(static_cast<int>((static_cast<double>(n)/static_cast<double>(frameNb)*100)));

    ui->label_2->setText("");
    if(n>=frameNb){
        timer.stop();
           display();}

}

void MainWindow::display(){
    timer2.setTimerType(Qt::TimerType::PreciseTimer);
    if(counter == 3){
        timer2.start(20);
    }else{
        if(frameNb > 50){
            timer2.start(100);}else{
        timer2.start(75);
    }
    }

}

void MainWindow::result(){

    *img2 = pictures[n2].copy();
    n2++;
    repaint();

            if(n2>=frameNb){
        timer2.stop();
    }
}

void MainWindow::start()
{
    *temp = img2->copy();
    timer.setTimerType(Qt::TimerType::PreciseTimer);
    timer.start(10);
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event){

    x = event-> x() - ui->frame->x();
    y = event -> y() - ui->frame->y();

    x2 = event-> x() - ui->frame_2->x();
    y2 = event -> y() - ui->frame_2->y();


    if(x0==x && y0 == y && x0 >= 0 && x0 <= ui->frame->width() && y0 >= 0 && y0 <= ui->frame->height()){
            setPixel(x0,y0,255,0,0,angelina);
            pointsX[counter] = x0;
            pointsY[counter] = y0;
            counter ++;

            if(counter % 3 == 0){
                xta = pointsX[counter - 3];
                yta = pointsY[counter - 3];
                xtb = pointsX[counter - 2];
                ytb = pointsY[counter - 2];
                xtc = pointsX[counter - 1];
                ytc = pointsY[counter - 1];

            }
    }
    else{
       isCklicked(x0,x,y0,y,pointsX, pointsY, angelina, img_prim, counter);
   }

    if(x1==x2 && y1 == y2 && x1 >= 0 && x1 <= ui->frame_2->width() && y1 >= 0 && y1 <= ui->frame_2->height()){
        setPixel(x1,y1,255,0,0,brad);
        pointsX2[counter2] = x1;
        pointsY2[counter2] = y1;
        counter2 ++;
        if(counter2 % 3 == 0){
            xta2 = pointsX2[counter - 3];
            yta2 = pointsY2[counter - 3];
            xtb2 = pointsX2[counter - 2];
            ytb2 = pointsY2[counter - 2];
            xtc2 = pointsX2[counter - 1];
            ytc2 = pointsY2[counter - 1];
        }

    }
    else{
        isCklicked(x1,x2,y1,y2,pointsX2, pointsY2, brad, img2_prim, counter2);
   }

    if(counter >= 3){
        clean(pointsX, pointsY, angelina, img_prim, counter);

    }

    if(counter2 >= 3){

       clean(pointsX2, pointsY2, brad, img2_prim, counter2);
    update();

}

update();
}


void MainWindow::isCklicked(int x1, int x2, int y1, int y2, int X[1000], int Y[1000], QImage *img, QImage *img2, int counter){
    if( x2 >= 0 && x2  <= img->width() && y2  >= 0 && y2 <= img->height()){
    for(int i = 0; i < counter; i++){
        if(abs(X[i] - x1) <= 3 && abs(Y[i] - y1) <= 3){
           setPixel(x2,y2,255,0,0,img);

           X[i] = x2;
           Y[i] = y2;

    uchar *wsk;

        for(int i = x1-5; i <= x1+5; i++){
            for(int j = y1 - 5; j <= y1 + 5; j++){

           wsk = img->scanLine(j);
           wsk[4 * i] = static_cast<uchar>(img2->pixelColor(i,j).blue());
           wsk[ 4 * i + 1] = static_cast<uchar>(img2->pixelColor(i,j).green());
           wsk[ 4 * i + 2] = static_cast<uchar>(img2->pixelColor(i,j).red());

             }
           }
        }
      }
    }
}

void MainWindow::clean(int X[1000], int Y[1000], QImage *img, QImage *img2, int counter2){
    uchar *wsk;
    for(int i = 0; i < img->width(); i++){
        for(int j = 0; j < img -> height(); j++){
                wsk = img->scanLine(j);
                wsk[4 * i] = static_cast<uchar>(img2->pixelColor(i,j).blue());
                wsk[ 4 * i + 1] = static_cast<uchar>(img2->pixelColor(i,j).green());
                wsk[ 4 * i + 2] = static_cast<uchar>(img2->pixelColor(i,j).red());

        }
    }
    for(int i = counter2; i > 2; i--){

    draw_section(X[i-3], Y[i-3],X[i-2], Y[i-2],255,0,0,img);
    draw_section(X[i-3], Y[i-3],X[i-1], Y[i-1],255,0,0,img);
    draw_section(X[i-1], Y[i-1],X[i-2], Y[i-2],255,0,0,img);

    setPixel(X[i-3], Y[i-3],255,0,0,img);
    setPixel(X[i-2], Y[i-2],255,0,0,img);
    setPixel(X[i-1], Y[i-1],255,0,0,img);
    }
}
void MainWindow::mousePressEvent(QMouseEvent *event){

    x0 = event-> x() - ui->frame->x();
    y0 = event -> y() - ui->frame->y();

    x1 = event-> x() - ui->frame_2->x();
    y1 = event -> y() - ui->frame_2->y();

}

void MainWindow::on_exit_clicked()
{
       qApp -> quit();
}

double MainWindow::count_det(double x0, double x1, double y0, double y1){
    return x0 * y1 - y0 * x1;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter p(this);

    p.drawImage(ui ->frame->x(), ui ->frame->y(), *angelina);
    p.drawImage(ui->frame_2->x(), ui->frame_2->y(), *brad);
    p.drawImage(ui->result->x(), ui->result->y(), *img2);

}

void MainWindow::draw(QImage *img2){
    uchar *wsk;
    for(int i = 0; i < ui->result->height(); i++)
    {
        wsk = img2->scanLine(i);
        for(int j = 0 ; j < ui->result->width(); j++)
        {
            wsk[4*j] = 255;// BLUE
            wsk[4*j + 1] = 255; // GREEN
            wsk[4*j + 2] = 255; // RED

        }
    }
}

void MainWindow::setPixel(int x, int y, int r, int g , int b, QImage *image ){
   uchar *wsk;
if(x >=0 && y >=0 && x <  ui->frame->width() && y <  ui->frame->height() ){
    if(x<3){
        x=3;
    }
    if(x+3>ui->frame->width()){
        x = x-3;
    }
    if(y<3){
        y=3;
    }
    if(y+3>ui->frame->height()){
        y = y-3;
    }
    for(int i = x-3; i < x+3; i++){
           for(int j = y - 3; j < y + 3; j++){

                   wsk = image->scanLine(j);
                   wsk[4 * i] = static_cast<uchar>(b);
                   wsk[ 4 * i + 1] = static_cast<uchar>(g);
                   wsk[ 4 * i + 2] = static_cast<uchar>(r);
           }
       }
}
    update();
}

void MainWindow::setCommonPixel(int x, int y, int r, int g , int b, QImage *image ){
   uchar *wsk;
if(x >=0 && y >=0 && x <  ui->frame->width() && y <  ui->frame->height() ){

                   wsk = image->scanLine(y);
                   wsk[4 * x] = static_cast<uchar>(b);
                   wsk[ 4 * x + 1] = static_cast<uchar>(g);
                   wsk[ 4 * x + 2] = static_cast<uchar>(r);

}
    update();
}


QImage MainWindow::barycentric(int xta, int yta, int xtb, int ytb, int xtc, int ytc,
                                        int xa, int ya, int xb, int yb, int xc, int yc, QImage *img_prim, QImage *img){
    double v, w, u;
    int min_x = MIN(xta,MIN(xtb,xtc));
    int max_x = MAX(xta, MAX(xtb,xtc));
    int min_y = MIN(yta,MIN(ytb,ytc));
    int max_y = MAX(yta, MAX(ytb,ytc));


    for(int i = min_x ; i <= max_x; i++){
        uchar *wsk;
        for(int j = min_y ; j <= max_y ; j++){
            wsk = img->scanLine(j);
            v = calculate_v(i, xta, xtb, xtc, j, yta, ytb, ytc);
            w = calculate_w(i, xta, xtb, xtc, j, yta, ytb, ytc);
            u = 1 - v - w;
           if(u <= 1 && u >= 0 && v <= 1 && v >= 0 && w <= 1 && w >= 0){

               int x_floor = qFloor(u * xa + v * xb + w * xc);
               int x_ceil = qCeil(u * xa + v * xb + w * xc);
               int y_floor = qFloor(u * ya + v * yb + w * yc);
               int y_ceil = qCeil(u * ya + v * yb + w * yc);

               QColor color_1 = img_prim->pixelColor(x_floor, y_floor);
               QColor color_2 = img_prim->pixelColor(x_ceil, y_floor);
               QColor color_3 = img_prim->pixelColor(x_ceil, y_ceil);
               QColor color_4 = img_prim->pixelColor(x_floor, y_ceil);

               double a = fabs(u * xa + v * xb + w * xc - x_floor);
               double b = fabs(u * ya + v * yb + w * yc - y_ceil);

             setCommonPixel
                       (static_cast<int>(round(u * xta + v * xtb + w * xtc)),
                        static_cast<int>(round(u * yta + v * ytb + w * ytc)),
                       static_cast<int>(b*((1-a)*color_1.red() + a * color_2.red()) + (1-b)*((1-a)*color_4.red() + a * color_3.red())),
                       static_cast<int>(b*((1-a)*color_1.green() + a * color_2.green()) + (1-b)*((1-a)*color_4.green() + a * color_3.green())),
                       static_cast<int>(b*((1-a)*color_1.blue() + a * color_2.blue()) + (1-b)*((1-a)*color_4.blue() + a * color_3.blue())),
                        img );
           }
        }
    }
    update();
    return *img;
}

double MainWindow::calculate_v(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc){
    double v = count_det(x - xa, xc - xa, y - ya, yc - ya) / count_det(xb - xa, xc - xa, yb - ya, yc - ya);
    return v;
}

double MainWindow::calculate_w(int x, int xa, int xb, int xc, int y, int ya, int yb, int yc){
    double w = count_det(xb - xa, x - xa, yb - ya, y - ya) / count_det(xb - xa, xc - xa, yb - ya, yc - ya);
    return w;
}


void MainWindow::on_reset_clicked()
{
   *angelina= img_prim->copy();
   *brad = img2_prim->copy();
    draw(img2);
    counter = 0;
    counter2 = 0;
    n = 0;
    n2 = 0;
    ui->horizontalSlider->setValue(0);
    update();
}

void MainWindow::draw_section(int x0, int y0, int x1, int y1, int r, int g, int b, QImage *img){

   if(x1 < x0){
      int temp = x0;
      x0 = x1;
      x1 = temp;
      int temp2 = y0;
      y0 = y1;
      y1 = temp2;
   }
   double dy = double(y1-y0);
   double dx = double(x1-x0);


if(dx==0.0){
    dx = 1;
}
    double  a = dy/dx;
   double  bb = y0 - a* x0;


  if(x0==x1){
       for(int y=y0; y <= y1; y++){
           int  x = int ((y-bb)/a);

               setCommonPixel(x, y, r, g, b,img);
       }
   }

if(fabs(dx) > fabs(dy)){
       for(int x = x0; x <= x1; x++){
        int  y = int (a * x + bb);

           setCommonPixel(x, y, r, g, b,img);

       }
}else{

    if(y1 < y0){
        int temp_y = y0;
        y0 = y1;
        y1 = temp_y;
        int temp_x = x0;
        x0 = x1;
        x1 = temp_x;
    }

    for(int y = y0; y <= y1; y++){
     int  x = int ((y-bb)/a);
        setCommonPixel(x, y, r, g, b,img);
        }
    }
}

void MainWindow::on_framesNb_valueChanged(int arg1)
{
    frameNb = arg1;
    reset();
}

void MainWindow::on_triangle_clicked(){
if(clicked % 2 == 1 &&(counter < 3 || counter2 < 3))
    {
    QMessageBox::warning(this, "Execution error.", "Mark the triangles on both photos.");
    }
else{
    start();
    }
}

